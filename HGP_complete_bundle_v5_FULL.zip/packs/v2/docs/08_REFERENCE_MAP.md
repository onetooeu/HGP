# Reference Map (reading categories)

This is a topic map, not an endorsement list.
- Thermodynamics (entropy, free energy)
- Information physics (Landauer principle, reversible computing)
- Metrology (noise, Allan deviation, PSD estimation)
- Experimental design (blinding, randomization, preregistration)
- Emergent gravity narratives (conceptual frame)
