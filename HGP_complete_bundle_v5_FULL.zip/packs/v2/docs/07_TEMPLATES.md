# Templates

## Preregistration template (minimal)
- Hypothesis ID:
- Primary endpoint:
- Secondary endpoints:
- ON/OFF schedule plan:
- Blinding method:
- Confounders to record:
- Analysis plan:
- Stop conditions:

## Lab notebook template
- Date/time:
- Operator:
- Environment:
- Setup changes:
- Calibration checks:
- Run IDs:
- Notes/anomalies:
