# HGP Scientific Research Pack (v2)

Downloadables:
- `HGP_Scientific_Research_Pack_v2.pdf` — long-form dossier
- `/docs` — deep-dive chapters + templates
- `/out` — generated figures + datasets (CSV/JSON)
- `/scripts` — helper scripts
- `HGP_original.pdf`, `HGP_extended.pdf` — source PDFs (provided by author)

Everything is structured for falsification-first research work. No hazardous build instructions are included.
